import Cocoa

print("Welcome to Corado's Temperature Convertor 🌡️")

let Celsius = 37
let Celsius_to_Fahrenheit = (Celsius * 9) / 5 + 32

print("The temperature is \(Celsius_to_Fahrenheit)˚F")
