// How to store ordered data in arrays

import Cocoa

var beatles = ["John", "Paul", "George", "Ringo"]
let number = [4, 8, 15, 16, 23, 42]
var temperatures = [25.3, 28.2, 26.4]

print(beatles[0])
print(number[1])
print(temperatures[2])

beatles.append("Adrian")
beatles.append("Allen")
beatles.append("Adrian")
beatles.append("Novall")
beatles.append("Vivian")
//temperatures.append("Chris") ❌

let firstBeatle = beatles[0]
let firstNumber = number[0]
//let notAllowed = firstBeatle + firstNumber ❌

var scores = Array<Int>()
scores.append(100)
scores.append(80)
scores.append(85)
print(scores[1])

var albums = [String]()
albums.append("Folklore")
albums.append("Fearless")
albums.append("Red")

var price = [9.99]
price.append(8.99)
price.append(5.99)
print(price.count)

var characters = ["Lana", "Pam","Ray", "Sterling"]
print(characters.count)

characters.remove(at: 2)
print(characters.count)

characters.removeAll()
print(characters.count)

let boneMovies = ["Casino Royale", "Spectre", "No Time to Die"]
print(boneMovies.contains("Frozen"))

let cities = ["London", "Tokyo", "Rome", "Budapest"]
print(cities.sorted())

let presidents = ["Bush", "Obama", "Trump", "Biden"]
let reversedPresidents = presidents.reversed()
print(reversedPresidents)
