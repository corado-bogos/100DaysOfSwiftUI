import Cocoa

let actor = "Denzel Washington"
let filename = "paris.jpg"
let result = "⭐️ You win! ⭐️"

let quote = "Then he tapped a sign saying \"Believe\" and walked away."
print(quote)

let movie = """
A day in
the life of an
Apple engineer
"""
print(movie)

let nameLenght = actor.count
print(nameLenght)

print(result.uppercased())

print(movie.hasPrefix("A day"))
print(filename.hasSuffix(".jpeg"))
