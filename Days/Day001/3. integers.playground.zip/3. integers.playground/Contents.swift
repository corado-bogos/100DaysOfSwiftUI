let score = 10

var reallyBig = 100000000
reallyBig = 100_000_000
reallyBig = 10_00000_000_0_0_0_0000

let lowerScore = score - 2
let higherScore = score + 10
let doubledScore = score * 2
let squaredScore = score / 2

var counter = 10
counter += 1
print(counter)

counter *= 2
counter -= 10
counter /= 2

let number = 120
print(number.isMultiple(of: 3))
