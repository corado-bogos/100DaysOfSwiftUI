// Checkpoint 2

import Cocoa

var fruits: [String] = ["apple", "banana", "cherry", "cherry"]

print(fruits.count)
