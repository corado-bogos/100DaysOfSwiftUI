// How to use type annotations

import Cocoa

// Basic value types
let playerName: String = "Roy"
let luckyNumber: Int = 13
let pi: Double = 3.141
var isAuthenticated: Bool = true

// Collections
var alubms: [String] = ["Red", "Fearless"]
var user: [String: String] = ["id": "@twostraws"]
var books: Set<String> = Set([
    "The Bluest Eye",
    "Foundation",
    "Gir, Woman, Other"
])

// Different ways to create empty arrays
var soda: [String] = ["Coke", "Pepsi", "Irn-Bru"]
var teams: [String] = [String]()
var cities: [String] = []
var clues = [String]()

// Enums
enum UIStyle {
    case light, dark, system
}

var style = UIStyle.light
style = .dark

// Constants set later
let username: String
// lots of complex logic
username = "@twostraws"
// lots more complex logic
print(username)
